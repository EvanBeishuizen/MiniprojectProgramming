__author__ = 'Dennis'

import ui
import QR
import database

db = "reisgegevens.db"

def setup(db):
    ui.setup()
    database.setup(db)
    #send_data(db,"Kerstman", 8573475, "Noordpool", "Zuidpool")


def send_data(db, naam, ov_nummer, beginstation, eindstation):
    database.insert_traveldata(db, naam, ov_nummer, beginstation, eindstation)
    QR.create_qr(database.get_travelID(db, ov_nummer))

setup(db)



