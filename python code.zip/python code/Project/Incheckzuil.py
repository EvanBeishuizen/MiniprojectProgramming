__author__ = 'Dennis'

import database
#import gui

db = "reisgegevens.db"

def setup(db):
    database.setup(db)
    #gui.setup()

def send_ovnummer(db,ov_nummer):
    gegevens = database.get_traveldata(db,ov_nummer)
    print("ovnummer:" + str(ov_nummer))
    print("naam: " + gegevens[0][2])
    print("\nReizen:")
    for row in gegevens:
        print("ReisID: " + str(row[0]))
        print("Beginstation: " + row[3])
        print("Eindstation: " + row[4] + "\n")



setup(db)
send_ovnummer(db, 8573475)

