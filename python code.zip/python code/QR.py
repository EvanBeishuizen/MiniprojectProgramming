__author__ = 'Dennis'

import qrcode
import qrcode.image.svg

def create_qr(reisid):
    factory = qrcode.image.svg.SvgPathImage
    img = qrcode.make(reisid, image_factory=factory)
    filename = str(reisid) + ".svg"
    img.save(filename)



