__author__ = 'Sander'
import qrcode
import qrcode.image.svg
factory = qrcode.image.svg.SvgPathImage
img = qrcode.make('Reiscode: 25X7G828WZ', image_factory=factory)
img.save("qr.svg")