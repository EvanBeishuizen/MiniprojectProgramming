#!/usr/bin/python3


from tkinter import *
velden = 'Naam', 'Ov-chipkaartnummer', 'Beginstation', 'Eindstation'



def fetch(invoer):
   for entry in invoer:
      field = entry[0]
      text  = entry[1].get()
      print('%s: "%s"' % (field, text)) 

def makeform(root, velden):

   invoer = []
   for veld in velden:

      row = Frame(root, bg='blue')

      lab = Label(row, width=18, text=veld, anchor='w', bg='yellow')
      ent = Entry(row)
      row.pack(side=TOP, fill=X, padx=40, pady=20)
      lab.pack(side=LEFT)
      ent.pack(side=RIGHT, expand=YES, fill=X)
      invoer.append((veld, ent))
      root.configure(bg='yellow')
   return invoer

if __name__ == '__main__':
   root = Tk()
   ents = makeform(root, velden)
   root.bind('<Return>', (lambda event, e=ents: fetch(e)))   
   b1 = Button(root, text='Voer in',
          command=(lambda e=ents: fetch(e)))
   b1.pack(side=LEFT, padx=100 , pady=20)
   b2 = Button(root, text='Sluiten', command=root.quit, fg='blue')
   b2.pack(side=LEFT, padx=50, pady=20)

   root.mainloop()
