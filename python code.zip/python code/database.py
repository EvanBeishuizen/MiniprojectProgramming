__author__ = 'Dennis'

import sqlite3
import os

def setup(database):
    checkIfDatabaseExists(database)

def checkIfDatabaseExists(database):
    if os.path.isfile(database) == False:
        create_database(database)

def create_database(database):
    conn = sqlite3.connect(database)
    c = conn.cursor()
    c.execute("Create table reisgegevens('reisID' INTEGER PRIMARY KEY AUTOINCREMENT, 'naam' TEXT, 'ov_nummer' INTEGER, 'beginstation' TEXT, 'eindstation' TEXT)")
    conn.commit()
    conn.close()

def insert_traveldata(database, naam, ov_nummer, beginstation, eindstation):
    conn = sqlite3.connect(database)
    c = conn.cursor()
    c.execute("INSERT into reisgegevens(naam,ov_nummer,beginstation,eindstation) values(?,?,?,?)",(naam,ov_nummer,beginstation,eindstation))
    conn.commit()

def get_travelID(database, ov_nummer):
    conn = sqlite3.connect(database)
    c = conn.cursor()
    c.execute('''SELECT reisID from reisgegevens where ov_nummer = ?''', (ov_nummer,))
    return c.fetchall()[-1][0]


def get_traveldata(database,reisID):
    conn = sqlite3.connect(database)
    c = conn.cursor()
    c.execute('''SELECT naam,beginstation,eindstation from reisgegevens where reisID = ?''', (reisID,))
    return c.fetchall()


def get_travelamount(database):
    conn = sqlite3.connect(database)
    c = conn.cursor()
    c.execute('''SELECT ov_nummer from reisgegevens''')
    return c.fetchall()







